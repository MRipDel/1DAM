/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ej_1_ud5;

/**
 *
 * @author Manuel Ripalda
 */

/*Realiza un programa que muestre por pantalla los 20 primeros números naturales
(1, 2, 3... 20).*/
public class Ej_1_UD5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int num=1;
        
        while(num<=20){
            
            System.out.println(num);
            
            num++;
        }
    }
    
}
