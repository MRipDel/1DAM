/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio01_ud5_b;
import java.util.Scanner;
/**
 *
 * @author Manuel Ripalda
 */
/*Realiza un programa que muestre por pantalla los 20 primeros números naturales (1, 2, 3... 20)
*/
public class Ejercicio01_Ud5_B {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int nums;
        
        Scanner pregunta=new Scanner(System.in);
        
        
    }
    
}
