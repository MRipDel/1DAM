/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ej_2_ud5;

/**
 *
 * @author Manuel Ripalda
 */

/*Realiza un programa que muestre los números pares comprendidos entre el 1 y el 200. Para ello
utiliza un contador y suma de 2 en 2.*/
public class Ej_2_UD5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int num;
        
        for (num = 2; num < 202; num=num+2) {
           
            System.out.println(num);
        
        }
        
    }
    
}
