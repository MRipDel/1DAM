/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ej_2_ud4;

/**
 *
 * @author usuario
 */
public class Ej_2_UD4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    /*Escribe un programa que calcule y muestre el área de un cuadrado de lado
    igual a 5.
    */

    int lado=5;
    // double areaCuadrado;
    
    //areaCuadrado= Math.pow(lado,2);
    
    System.out.println(Math.pow(lado,2));
    
    }
    
}
